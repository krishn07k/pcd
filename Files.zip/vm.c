#include<stdio.h>

int main()
{
    int pg,fn,size,start,pgno,ins,frameno;

    printf("Enter the no. of pages : ");
    scanf("%d",&pg);

    printf("Enter the no. of frames : ");
    scanf("%d",&fn);

    printf("Enter the frame size : ");
    scanf("%d",&size);

    printf("Enter the starting address : ");
    scanf("%d",&start);

    int pgtable[pg][2],i,j,f=-1;

    printf("Enter the page table :\n");
    
    for(i=0;i<pg;i++)
     {
        printf("PAGE NO. : ");
        scanf("%d",&pgtable[i][0]);
        printf("FRAME NO. : ");
        scanf("%d",&pgtable[i][1]);
     }
 
     printf("Enter the page no. to execute : ");
     scanf("%d",&pgno);

     printf("Enter the instruction no. to execute : ");
     scanf("%d",&ins);

     for(i=0;i<pg;i++)
      {
          if(pgtable[i][0]==pgno)
            {
                frameno=pgtable[i][1];
                f++;
            }
      }
      
      int frameaddr;

      if(f==-1)
        printf("No such page exists");
      
      else
       {
         frameaddr=(start+(frameno+1)*(size));

         printf("Frame Address : %d\n",frameaddr);
       }
    return 0;

 }
