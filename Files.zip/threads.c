#include<stdio.h>
#include<string.h>
#include<pthread.h>
#include<stdlib.h>
#include<unistd.h>
pthread_t tid[2];

void* sample(){
    printf("Execute thread\n");
    sleep(2);
    printf("Finished execution\n");

}

int main(int argc, char* argv[]){
    pthread_t ids[2];
    pthread_create(&ids[0],NULL,&sample,NULL);
    pthread_create(&ids[1],NULL,&sample,NULL);
    pthread_join(ids[0],NULL);
    pthread_join(ids[1],NULL);
    return 0;
}